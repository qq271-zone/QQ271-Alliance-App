package com.qq271.alliance;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;

public class SplashActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFFFFF7FB);

        ImageView splash = new ImageView(this);
        splash.setImageResource(R.drawable.splash_screen);
        splash.setScaleType(ImageView.ScaleType.CENTER_CROP);
        splash.setAlpha(0f);
        splash.setScaleX(0.975f);
        splash.setScaleY(0.975f);

        root.addView(splash, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT,
            Gravity.CENTER
        ));
        setContentView(root);

        splash.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(520)
            .withEndAction(() -> new Handler(Looper.getMainLooper()).postDelayed(() -> {
                splash.animate().alpha(0f).scaleX(1.018f).scaleY(1.018f).setDuration(280)
                    .withEndAction(() -> {
                        startActivity(new Intent(SplashActivity.this, MainActivity.class));
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        finish();
                    }).start();
            }, 800)).start();
    }
}
